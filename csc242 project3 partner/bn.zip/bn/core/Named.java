package bn.core;

/**
 * Interface implemented by things that have names.
 */
public interface Named {
	
	public String getName();

}
